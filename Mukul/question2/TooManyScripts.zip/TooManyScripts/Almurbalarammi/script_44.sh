#!/bin/bash
echo 'Congratulations! You have found a hidden script , But Not this one ;)'
echo 'Good , but Flag is not here '

