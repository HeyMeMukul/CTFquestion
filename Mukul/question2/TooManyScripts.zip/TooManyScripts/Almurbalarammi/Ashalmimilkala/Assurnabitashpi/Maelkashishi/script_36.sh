#!/bin/bash
echo 'Congratulations! You have found a hidden script , But Not this one ;)'
echo ' Here it is H&SCTF{Ju5t_t0_w4st3_y0ur_tim3} '

