#!/bin/bash
echo 'Congratulations! You have found a hidden script , But Not this one ;)'
echo ' Great You are Here , Here is you flag -- go 10 script before this one '

