#!/bin/bash
echo 'Congratulations! You have found a hidden script , But Not this one ;)'
echo ' But in next window :) '

