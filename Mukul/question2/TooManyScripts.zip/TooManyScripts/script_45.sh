#!/bin/bash
echo 'Congratulations! You have found a hidden script , But Not this one ;)'
echo ' Between 40-50 but not here '
